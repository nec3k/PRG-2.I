-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Pát 17. led 2020, 13:10
-- Verze serveru: 10.1.26-MariaDB-0+deb9u1
-- Verze PHP: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `u304`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `2-20-eshop_karegorie`
--

CREATE TABLE `2-20-eshop_karegorie` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `poradi` int(11) NOT NULL,
  `aktivni` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `2-20-eshop_karegorie`
--

INSERT INTO `2-20-eshop_karegorie` (`id`, `nazev`, `poradi`, `aktivni`) VALUES
(1, 'mobily', 1, 1),
(2, 'monitory', 2, 0),
(3, 'myši', 3, 0),
(4, 'klávenice', 4, 1),
(5, 'notebooky', 5, 1),
(6, 'počitače', 6, 0),
(7, 'pečivo', 7, 1),
(8, 'oblečení', 8, 0),
(9, 'nápoje', 9, 1),
(10, 'umyvadla', 10, 0);

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `2-20-eshop_karegorie`
--
ALTER TABLE `2-20-eshop_karegorie`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `poradi` (`poradi`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `2-20-eshop_karegorie`
--
ALTER TABLE `2-20-eshop_karegorie`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
