-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Úte 28. led 2020, 11:37
-- Verze serveru: 10.1.26-MariaDB-0+deb9u1
-- Verze PHP: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `u304`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `2_21_U25_stat`
--

CREATE TABLE `2_21_U25_stat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `kontinent_id` bigint(20) UNSIGNED NOT NULL,
  `rozloha` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `2_21_U25_stat`
--

INSERT INTO `2_21_U25_stat` (`id`, `nazev`, `kontinent_id`, `rozloha`) VALUES
(1, 'Brazílie', 6, NULL),
(3, 'Vietnam', 1, 154112),
(4, 'Japonsko', 1, 444411),
(5, 'Čína', 1, 666444),
(6, 'Mongolsko', 1, NULL),
(7, 'Francie', 2, 21547),
(8, 'Finsko', 2, 55211),
(9, 'Nigérie', 4, NULL);

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `2_21_U25_stat`
--
ALTER TABLE `2_21_U25_stat`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `kontinent_fk` (`kontinent_id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `2_21_U25_stat`
--
ALTER TABLE `2_21_U25_stat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `2_21_U25_stat`
--
ALTER TABLE `2_21_U25_stat`
  ADD CONSTRAINT `kontinent_fk` FOREIGN KEY (`kontinent_id`) REFERENCES `2_21_U25_kontinent` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
