-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Úte 04. úno 2020, 11:38
-- Verze serveru: 10.1.26-MariaDB-0+deb9u1
-- Verze PHP: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `u304`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `eshop_vyrobce`
--

CREATE TABLE `eshop_vyrobce` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `jmeno` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `logo` varchar(200) COLLATE utf8_czech_ci NOT NULL,
  `popis` longtext COLLATE utf8_czech_ci NOT NULL,
  `hodnoceni` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `eshop_vyrobce`
--

INSERT INTO `eshop_vyrobce` (`id`, `jmeno`, `logo`, `popis`, `hodnoceni`) VALUES
(0, 'Tesco', 'tesco.jpg', 'Dlouhý popis výrobce ... ', 3),
(1, 'Apple', 'apple.jpg', 'Velmi dobrý výrobce', 7),
(3, 'HP', 'hp.jpg', 'Ještě delší popis výrobce ... ', 6),
(4, 'Dell', 'dell.jpg', 'Kvalitní výrobce', 9),
(5, 'Asus', 'Asus.jpg', 'Popis .. ', 1),
(6, 'Nokia', 'nokia.jpg', 'Výrobce telefonů', 9);

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `eshop_vyrobce`
--
ALTER TABLE `eshop_vyrobce`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `eshop_vyrobce`
--
ALTER TABLE `eshop_vyrobce`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
