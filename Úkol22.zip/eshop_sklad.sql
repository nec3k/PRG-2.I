-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Úte 04. úno 2020, 11:38
-- Verze serveru: 10.1.26-MariaDB-0+deb9u1
-- Verze PHP: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `u304`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `eshop_sklad`
--

CREATE TABLE `eshop_sklad` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `psc` varchar(5) COLLATE utf8_czech_ci NOT NULL,
  `mesto` varchar(200) COLLATE utf8_czech_ci NOT NULL,
  `ulice` varchar(200) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `eshop_sklad`
--

INSERT INTO `eshop_sklad` (`id`, `nazev`, `psc`, `mesto`, `ulice`) VALUES
(0, 'Sklad 1', '41108', 'Štětí', 'Obchodní'),
(2, 'Sklad 2', '41100', 'Litoměřice', 'Dlouhá'),
(3, 'Sklad 3', '41101', 'Roudnice nad Labem', 'Krátká'),
(4, 'Sklad 4', '41200', 'Brno', 'Hlavní'),
(5, 'Sklad 5', '41300', 'Ostrava', 'Obchodní');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `eshop_sklad`
--
ALTER TABLE `eshop_sklad`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `eshop_sklad`
--
ALTER TABLE `eshop_sklad`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
