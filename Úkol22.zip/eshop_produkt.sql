-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Úte 04. úno 2020, 11:38
-- Verze serveru: 10.1.26-MariaDB-0+deb9u1
-- Verze PHP: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `u304`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `eshop_produkt`
--

CREATE TABLE `eshop_produkt` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `poradi` int(11) NOT NULL,
  `dlouhy_popis` longtext COLLATE utf8_czech_ci NOT NULL,
  `obrazek` varchar(200) COLLATE utf8_czech_ci NOT NULL,
  `kategorie` bigint(20) UNSIGNED NOT NULL,
  `sklad` bigint(20) UNSIGNED NOT NULL,
  `vyrobce` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `eshop_produkt`
--

INSERT INTO `eshop_produkt` (`id`, `nazev`, `poradi`, `dlouhy_popis`, `obrazek`, `kategorie`, `sklad`, `vyrobce`) VALUES
(1, 'Nokia 3310', 1, 'Telefon', 'nokia.png', 1, 0, 6),
(2, 'iPhone 4', 2, 'Smartphone', 'iphone.png', 1, 2, 1),
(3, 'Genius', 1, 'Obyčejná klávesnice', 'genius.jpg', 4, 2, 4),
(4, 'Dell', 2, 'Mechanická klávesnice', 'dell.jpg', 4, 2, 4),
(5, 'Logitech', 3, 'Herní klávesnice', 'logitech.png', 4, 0, 4),
(6, 'HP 250 G6', 1, 'Levný notebook od HP', 'hp.png', 5, 3, 3),
(7, 'Voda', 1, 'Minerální voda', 'voda.png', 9, 3, 0),
(8, 'Rohlík', 1, 'Velmi dlouhý popis rohlíku', 'rohlik.jpg', 7, 3, 0),
(9, 'Chleba', 2, 'Zdravý chleba', 'chleba.jpg', 7, 3, 0),
(10, 'houska', 3, 'Houska', 'houska.jpg', 7, 4, 0);

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `eshop_produkt`
--
ALTER TABLE `eshop_produkt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `kategorie_fk` (`kategorie`),
  ADD KEY `sklad_fk` (`sklad`),
  ADD KEY `vyrobce_fk` (`vyrobce`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `eshop_produkt`
--
ALTER TABLE `eshop_produkt`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `eshop_produkt`
--
ALTER TABLE `eshop_produkt`
  ADD CONSTRAINT `kategorie_fk` FOREIGN KEY (`kategorie`) REFERENCES `eshop_karegorie` (`id`),
  ADD CONSTRAINT `sklad_fk` FOREIGN KEY (`sklad`) REFERENCES `eshop_sklad` (`id`),
  ADD CONSTRAINT `vyrobce_fk` FOREIGN KEY (`vyrobce`) REFERENCES `eshop_vyrobce` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
