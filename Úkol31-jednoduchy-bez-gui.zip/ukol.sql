-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Ned 07. čen 2020, 15:00
-- Verze serveru: 10.1.26-MariaDB-0+deb9u1
-- Verze PHP: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `u304`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `ukol`
--

CREATE TABLE `ukol` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `popis` varchar(300) COLLATE utf8_czech_ci NOT NULL,
  `datum` varchar(50) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `ukol`
--

INSERT INTO `ukol` (`id`, `popis`, `datum`) VALUES
(1, 'Domácí úkol z Matematiky, str 11/2.', '0000-00-00 00:00:00'),
(2, 'Napište slohovou práci na 200 řádků', '2020-06-07 14:34:19'),
(3, 'Testovací úkol číslo jedna', '2020-06-07 14:35:24'),
(6, 'Testovací úkol číslo dva', '2020-06-07 14:47:12');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `ukol`
--
ALTER TABLE `ukol`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `ukol`
--
ALTER TABLE `ukol`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
