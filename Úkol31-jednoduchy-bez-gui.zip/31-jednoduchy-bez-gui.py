import mysql.connector


def pridat(popis):
    mycursor = mydb.cursor()
    mycursor.execute("INSERT INTO `ukol` (`id`, `popis`, `datum`) VALUES (NULL, '"+popis+"', CURRENT_TIMESTAMP)")
    mydb.commit()
    print("Úkol byl úspěšně přidán do databáze! ")


def vypsat():
    mycursor = mydb.cursor()
    mycursor.execute("SELECT COUNT(id) FROM `ukol`")
    celkem = mycursor.fetchone()[0]
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM `ukol`")
    myresult = mycursor.fetchall()
    if myresult:
        print("id, název, kontinent, rozloha:")
        for i in myresult:
            print(i)
    print("Celkový počet úkolů v DB je "+str(celkem))


def smazat(id):
    mycursor = mydb.cursor()
    mycursor.execute("SELECT popis FROM `ukol` WHERE id = "+str(id))
    myresult = mycursor.fetchone()
    if myresult:
        potvrzeni = input("Opravdu chcete smazat "+myresult[0]+"? (Ano/Ne): ")
        if potvrzeni.lower() == "ano":
            mycursor.execute("DELETE FROM `ukol` WHERE `ukol`.`id` = " + str(id))
            mydb.commit()
            print("Úkol "+myresult[0]+" byl úspěšně smazán!")
        else:
            print("Nezadali jste 'Ano' !! Váš úkol NEBUDE smazán ... ")
    else:
        print("Úkol s tímto ID neexistuje ...")


def editovat(id, popis):
    mycursor = mydb.cursor()
    mycursor.execute("UPDATE `ukol` SET `popis` = '"+popis+"' WHERE `ukol`.`id` = "+str(id)+";")
    mydb.commit()
    print("Úkol byl úspěšně upraven.")


def spustit_program():
    while True:
        print("""----------------------------------------------
        (1) Vypsat seznam úkolů
        (2) Vložit nový úkol
        (3) Smazat úkol podle ID
        (4) Upravit úkol
        (5) Konec aplikace\n""")
        try:
            akce = int(input("Co chceš udělat: "))
            if akce not in range(1, 6):
                raise ValueError
            if akce == 1:
                vypsat()
            if akce == 2:
                text = input("Zadejte popis úkolu: ")
                pridat(text)
            if akce == 3:
                id_ukolu = input("Zadejte ID úkolu: ")
                smazat(id_ukolu)
            if akce == 4:
                id_ukolu = input("Zadejte ID úkolu, který chcete editovat: ")
                novy_popis = str(input("Zadejte nový popis úkolu: "))
                editovat(id_ukolu, novy_popis)
            if akce == 5:
                break
        except ValueError:
            print("Zadejte číslo od 1 do 4")
        except:
            print("Někde se stala chyba ...")


mydb = mysql.connector.connect(
        host="studenti.odbornaskola.cz",
        user="uXXX",
        passwd="heslo",
        database="uXXX",
        port="3306")
spustit_program()
